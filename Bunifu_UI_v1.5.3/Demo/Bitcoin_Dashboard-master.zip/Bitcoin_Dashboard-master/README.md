# Bitcoin Dashboard Demo

Steps on getting started
Bunifu Framework Controls used in this project

* BunifuFlatButton
* BunifuDataViz
* BunifuElipse
* BunifuDragControl
* BunifuTransition
* BunifuSeparator
* BunifuImageButton
* BunifuCustomLabel
* BunifuMaterialTextBox
* BunifuCards

Screenshot

![](https://github.com/bunifu-framework/Bitcoin_Dashboard/blob/master/sc3.PNG)

Try/Buy [https://bunifuframework.com]